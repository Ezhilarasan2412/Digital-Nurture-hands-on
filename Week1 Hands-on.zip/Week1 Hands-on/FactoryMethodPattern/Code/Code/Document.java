package factory;

public interface Document {
    void open();
}
