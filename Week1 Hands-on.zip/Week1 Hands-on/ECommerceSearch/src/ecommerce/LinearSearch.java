package ecommerce;

public class LinearSearch {
    public static Product search(Product[] products, int id) {
        for (Product p : products) {
            if (p.productId == id) {
                return p;
            }
        }
        return null;
    }
}
